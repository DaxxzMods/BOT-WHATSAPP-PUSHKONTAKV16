This script create by DaxxzMods
if you want to buy this script, contact me in telegram https://t.me/DaffError505 and you can tell me in whatsapp https://wa.me/6285283112644 
don't forget to follow my instagram and my github https://www.instagram.com/daxxzmods | https://github.com/daxxzmods 
i'am sharing a script but not script bot whatsapp, i'am sharing script bot whatsapp in my channels whatsapp, you can join free, chat me in my whatsapp or telegram account, and done, you are joining to my channels whatsapp.
want to making another feature for bot whatsapp? tell me guys

don't delete this credits yeah broww :)
FOLLOW MY INSTAGRAM ACCOUNT, TELEGRAM CHANNELS, WHATSAPP CHANNELS, TO GOT A MORE SCRIPT BOT WHATSAPP OR TELEGRAM.
and don't forget to donate to my E-Wallet:
DANA: 081295532922
GOPAY: 081295532922
OVO: 081295532922

SEE U IN NEXT VERSION BOT WHATSAPP