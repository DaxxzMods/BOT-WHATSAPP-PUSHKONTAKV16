/*THIS SCRIPT CREATED BY DAXXZMODS
YOU CAN BUY THIS  SCRIPT FROM ME IN MY TELEGRAM

TELEGRAM: @DaffError505
Instagram: daxxzmods
Github: DaffBotz
Type Script: BOT PUSHKONTAK, JPM, GUARD GROUP
Price: 15K

*/

module.exports = async (daffmods, m, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const rdm = () =>{
const randomNumbers = [];
for (let i = 0; i < 10; i++) {
  const randomNumber = Math.floor(Math.random() * 10);
  randomNumbers.push(randomNumber);
}
return randomNumbers.join('')
}
const makeid = rdm()
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await daffmods.decodeJid(daffmods.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await daffmods.groupMetadata(m.chat) : {}
let participant_bot = isGroup ? groupMetadata?.participants?.find((v) => v.id == botNumber) : ''
let participant_sender = isGroup ? groupMetadata?.participants?.find((v) => v.id == m.sender) : ''
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { version } = require("./package.json")
const speed = require('performance-now')
const QRCode = require('qrcode')
const qris = require('./all/qris.js');
const { runtime, getRandom, formatp, getTime, tanggal, telegraPh, jsonformat, format, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./all/function.js')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./all/converter.js")
const antilink = JSON.parse(fs.readFileSync('./all/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./all/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const reseller = JSON.parse(fs.readFileSync("./all/database/reseller.json"))
const reseller2 = JSON.parse(fs.readFileSync("./all/database/reseller2.json"))
const prem = JSON.parse(fs.readFileSync("./prem.json"))
const db_respon_list = JSON.parse(fs.readFileSync('./list.json'))
let db_saweria = JSON.parse(fs.readFileSync('./all/saweria.json'))
const { teksjpm } = require('./all/database/teksjpm.js')
const jsobfus = require('javascript-obfuscator')
const { Client } = require('ssh2');
const LINODE_API_TOKEN = global.apilinode;
const API_TOKEN = global.apitokendo;
let isReseller = reseller.includes(m.sender)
if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}
let isPrem = prem.includes(m.sender)
if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}
let isReseller2 = reseller2.includes(m.sender)
if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}
const totalFitur = () =>{
            var mytext = fs.readFileSync("./casenyabang.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};
const tanggal2 = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const hariini = moment.tz('Asia/Jakarta')      
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')  
if(time2 < "23:59:00"){
var stime = (`Good Night`)
 }
 if(time2 < "19:00:00"){
var stime = (`Good Evening`)
 }
 if(time2 < "18:00:00"){
var stime = (`Good Evening`)
 }
 if(time2 < "15:00:00"){
var stime = (`Good Afternoon`)
 }
 if(time2 < "11:00:00"){
var stime = (`Good Morning`)
 }
 if(time2 < "05:00:00"){
var stime = (`Good Morning`)
 }
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')

async function dellCase(filePath, caseNameToRemove) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan:', err);
            return;
        }

        const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
        const modifiedData = data.replace(regex, '');

        fs.writeFile(filePath, modifiedData, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err);
                return;
            }

            console.log(`Teks dari case '${caseNameToRemove}' telah dihapus dari file.`);
        });
    });
}
const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"ͲᎡᎪᎪͲᏃᎽᎽ ϴҒᏟ  # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
function pickrandomref() {
  var symbols = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  var symbolLength = symbols.length;
  var currentDate = new Date();
  
  // Generate a random 3-letter symbol
  var randomSymbol = '';
  for (var i = 0; i < 3; i++) {
    randomSymbol += symbols.charAt(Math.floor(Math.random() * symbolLength));
  }

  var randomString = 'Rafa' +
    currentDate.getFullYear() +
    ('0' + (currentDate.getMonth() + 1)).slice(-2) +
    ('0' + currentDate.getDate()).slice(-2) + randomSymbol;

  return randomString;
}
let koderef = pickrandomref()

function toRupiah(angka) {
  var angkaStr = angka.toString();
  var angkaTanpaKoma = angkaStr.split('.')[0];
  var angkaRev = angkaTanpaKoma.toString().split('').reverse().join('');
  var rupiah = '';
  for (var i = 0; i < angkaRev.length; i++) {
    if (i % 3 == 0) rupiah += angkaRev.substr(i, 3) + '.';
  }
  return '' + rupiah.split('', rupiah.length - 1).reverse().join('');
}
function pickrandoms() {
  var symbols = '0123456789';
  var symbolLength = symbols.length;
  var randomString = 'P';
  for (var i = 0; i < 2; i++) {
    randomString += symbols.charAt(Math.floor(Math.random() * symbolLength));
  }
  randomString += '';
  for (var j = 0; j < 4; j++) {
    randomString += symbols.charAt(Math.floor(Math.random() * symbolLength));
  }
  return randomString;
}

    
const nebal = (angka) => {
return Math.floor(angka)
}
function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return daffmods.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return daffmods.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}
//=================================================//
//=================================================//
let ppuser
try {
ppuser = await daffmods.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/30c0edbb3f11fce2e5245.jpg'
}

async function daffReply(teks) {
return daffmods.sendMessage(m.chat, {text: `${teks}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnailUrl: ppuser, title: "KilzzBotz V16", body: "© Powered By "+namaowner, previewType: "PHOTO"}}}, {quoted: m})
}

async function loading () {
var gen2 = [
"procces",
"please wait...",
"..."
]
let { rafa } = await daffmods.sendMessage(m.chat, {text: 'Succes'})

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

for (let i = 0; i < gen2.length; i++) {
await sleep(10)
await daffmods.sendMessage(m.chat, {text: gen2[i], edit: rafa });
}
}

const qpayment = {
key: {
remoteJid: '0@s.whatsapp.net',
fromMe: false,
id: `ownername`,
participant: '0@s.whatsapp.net'
},
message: {
requestPaymentMessage: {
currencyCodeIso4217: "USD",
amount1000: 999999999,
requestFrom: '0@s.whatsapp.net',
noteMessage: {
extendedTextMessage: {
text: namabot
}},
expiryTimestamp: 999999999,
amount: {
value: 91929291929,
offset: 1000,
currencyCode: "INR"
}}}}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390@newsletter`,
newsletterName: `DaxxzMods`,
jpegThumbnail: "",
caption: `Powered By ${namaowner}`,
inviteExpiration: Date.now() + 1814400000
}
}}

const qtoko = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
}, message: {
"productMessage": {
"product": {
"productImage": {
"mimetype": "image/jpeg",
"jpegThumbnail": "",
},
"title": `Pterodactyl Server By ${namaowner}`,
"description": null,
"currencyCode": "IDR",
"priceAmount1000": "9999999999",
"retailerId": `Powered By DaxxzMods`,
"productImageCount": 1
},
"businessOwnerJid": `0@s.whatsapp.net`
}}
}

const qtext = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "0@s.whatsapp.net"} : {}) },'message': {extendedTextMessage: {text: "Thank you for using my services"}}}

const qdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: `Powered By ${namaowner}`, jpegThumbnail: ""}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp By DaxxzMods`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot By DaxxzMods`,jpegThumbnail: ""}}}

const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `${namaowner}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6285857537269:+62 882-2113-3538\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

if (global.owneroff && !isCmd) {
if (!isGroup && !isOwner) {
let teks = `*Hai Kak* @${m.sender.split('@')[0]}

Maaf *Ownerku Sedang Offline*, Silahkan Tunggu Owner Kembali Online & Jangan Spam Chat Atau Bisa Hubungi Melalui Telegram *t.me/DaffError505*`
return daffmods.sendMessage(m.chat, {text: `${teks}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnail: fs.readFileSync("./media/ownermode.jpg"), renderLargerThumbnail: false, title: "｢ OWNER OFFLINE MODE ｣", mediaUrl: linkgc, sourceUrl: linkyt, previewType: "PHOTO"}}}, {quoted: null})
}}

if (antilink.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await daffmods.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await daffmods.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnail: fs.readFileSync("./media/warning.jpg"), title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await daffmods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await daffmods.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

if (antilink2.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await daffmods.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await daffmods.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnail: fs.readFileSync("./media/warning.jpg"), title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await daffmods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}


switch (command) {
case "menu": {
teksmenunya = `
*Hallo* @${m.sender.split("@")[0]},\nSelamat ${ucapan()}\nSaya Adalah Bot Whatsapp khusus pushkontak yang diciptakan oleh daxxzmods untuk memudahkan anda dalam kegiatan pushkontak. 

*◦ Botname :* ${global.namabot2}
*◦ Creator :* ${global.owner}
*◦ Mode :* ${daffmods.public ? 'Public' : 'Self'}
*◦ Runtime :* ${runtime(process.uptime())}
*◦ Version :* ${version}
 
if you want to see all menu in this bot, type .allmenu`
daffReply(teksmenunya)
}
break
case "allmenu": {

let teksmenu = `
*Haii* @${m.sender.split("@")[0]}\nSelamat ${ucapan()}
 
*─ 乂ᴘ ᴜ s ʜ - ᴍ ᴇ ɴ ᴜ*
┌─
│ ᴘᴜsʜᴋᴏɴᴛᴀᴋ 
│ ᴘᴜsʜᴋᴏɴᴛᴀᴋ𝟷 
│ ᴘᴜsʜᴋᴏɴᴛᴀᴋ𝟸
│ sᴀᴠᴇᴋᴏɴᴛᴀᴋ 
│ sᴀᴠᴇᴋᴏɴᴛᴀᴋ𝟸 
│ ʟɪsᴛɢᴄ 
│ ɪᴅɢᴄ 
│ ᴊᴘᴍ 
│ ᴊᴘᴍ𝟸 
│ ᴊᴘᴍᴘʀᴏᴍᴏsɪ 
│ ᴊᴘᴍᴛᴇsᴛɪ 
│ ᴊᴘᴍʜɪᴅᴇᴛᴀɢ 
│ sᴛᴀʀᴛᴊᴘᴍ 
│ sᴇᴛᴛᴇᴋsᴊᴘᴍ 
│ ᴛᴇᴋsᴊᴘᴍ 
│ ᴊᴘᴍsʟɪᴅᴇ 
└ ─

*─ 乂 ɢ ʀ ᴏ ᴜ ᴘ - ᴍ ᴇ ɴ ᴜ*
┌─
│ ᴀᴅᴅᴍᴇᴍʙᴇʀ 
│ ᴀɴᴛɪʟɪɴᴋ 
│ ᴀɴᴛɪʟɪɴᴋᴠ𝟸 
│ ʜɪᴅᴇᴛᴀɢ 
│ ᴛᴀɢᴀʟʟ 
│ ᴅᴇʟᴇᴛᴇ 
│ ᴏᴘᴇɴ/ᴄʟᴏsᴇ 
│ ᴏᴘᴇɴᴛɪᴍᴇ 
│ ᴄʟᴏsᴇᴛɪᴍᴇ 
│ sᴇᴛɴᴀᴍᴀɢᴄ 
│ sᴇᴛᴅᴇsᴋɢᴄ 
│ sᴇᴛᴘᴘɢᴄ 
│ ᴋɪᴄᴋ 
│ ᴘʀᴏᴍᴏᴛᴇ 
│ ʟᴇᴀᴠᴇɢᴄ 
│ ʟᴇᴀᴠᴇɢᴄ𝟸 
│ ᴅᴇᴍᴏᴛᴇ 
└ ─

*─ 乂 ᴏ ᴡ ɴ ᴇ ʀ - ᴍ ᴇ ɴ ᴜ*
┌─
│ ᴄʟᴇᴀʀsᴇssɪᴏɴ 
│ ᴍᴏᴅᴇᴏғғ 
│ ᴍᴏᴅᴇᴏɴ 
│ ᴊᴏɪɴ 
│ ᴅᴏɴᴇ 
│ ᴀɴᴛɪᴄᴀʟʟ 
│ ᴀᴜᴛᴏʀᴇᴀᴅ 
│ ʀᴇsᴛᴀʀᴛ 
│ ʀᴜɴᴛɪᴍᴇ 
│ ᴀᴅᴅᴄᴀsᴇ 
│ ᴅᴇʟᴄᴀsᴇ 
│ ɢᴇᴛᴄᴀsᴇ 
│ ʟɪsᴛᴄᴀsᴇ 
│ ʙʟᴏᴄᴋ 
│ ᴜɴʙʟᴏᴄᴋ 
│ ʟɪsᴛʙʟᴏᴄᴋ 
│ ᴡᴇʟᴄᴏᴍᴇ 
│ sᴇᴛᴛʜᴜᴍʙɴᴀɪʟ 
│ sᴇᴛᴘᴘʙᴏᴛᴘᴀɴᴊᴀɴɢ 
│ ᴄʜᴀɴɢᴇᴍᴇɴᴜ 
│ ᴀᴅᴅᴘʀᴇᴍ 
│ ᴅᴇʟᴘʀᴇᴍ 
│ ʟɪsᴛᴘʀᴇᴍ 
│ sᴘᴇᴋʀᴀᴍ 
│ ʙʀᴏᴀᴅᴄᴀsᴛ  
│ ʙʀᴏᴀᴅᴄᴀsᴛᴠ𝟸 
│ sᴇᴛᴘᴘʙᴏᴛ 
│ sᴇᴛɴᴀᴍᴀʙᴏᴛ 
│ sᴇᴛʙɪᴏʙᴏᴛ 
│ ᴄᴇᴋʙᴏᴛ 
│ ɢᴄᴀsᴛ 
│ ɢᴄᴀsᴛᴠ𝟸 
│ ʟɪsᴛᴘᴄ 
│ ʙᴄɢᴄ 
│ ʙᴄɢᴄᴠ𝟸 
│ ᴘɪɴɢ 
└ ─

*\`Copyright${global.owner}\`*
`
daffmods.sendOrder(m.chat, teksmenu, fs.readFileSync('./media/thumbnail.jpg'), "99999999", 10000000, qchanel)
}
break
case "grupmenu": {

let teksmenu = `
*Haii* @${m.sender.split("@")[0]}\nSelamat ${ucapan()}

*\`乂 ɢ ʀ ᴏ ᴜ ᴘ ᴍ ᴇ ɴ ᴜ\`*

* ᴀᴅᴅᴍᴇᴍʙᴇʀ
* ᴀɴᴛɪʟɪɴᴋ
* ᴀɴᴛɪʟɪɴᴋᴠ𝟸
* ʜɪᴅᴇᴛᴀɢ
* ᴛᴀɢᴀʟʟ
* ᴅᴇʟᴇᴛᴇ
* ᴏᴘᴇɴ/ᴄʟᴏsᴇ
* sᴇᴛɴᴀᴍᴀɢᴄ
* sᴇᴛᴅᴇsᴋɢᴄ
* sᴇᴛᴘᴘɢᴄ
* ᴋɪᴄᴋ
* ᴘʀᴏᴍᴏᴛᴇ
* ʟᴇᴀᴠᴇɢᴄ
* ʟᴇᴀᴠᴇɢᴄ𝟸
* ᴅᴇᴍᴏᴛᴇ

*\`𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 ${global.owner}\`*
`
daffmods.sendMessage(m.chat, {text: `${teksmenu}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: fs.readFileSync("./media/thumbnail2.jpg"), title: `© ${namabot} - ${version}`, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
}
break
case "ownermenu": {

let teksmenu = `
*Haii* @${m.sender.split("@")[0]}\nSelamat ${ucapan()}

*\`乂 ᴏ ᴡ ɴ ᴇ ʀ ᴍ ᴇ ɴ ᴜ\`*

* ᴄʟᴇᴀʀsᴇssɪᴏɴ
* ᴀᴄᴄʀᴇᴘᴏʀᴛ
* ᴍᴏᴅᴇᴏғғ
* ᴍᴏᴅᴇᴏɴ
* ᴊᴏɪɴ
* ᴅᴏɴᴇ
* ᴀɴᴛɪᴄᴀʟʟ
* ᴀᴜᴛᴏʀᴇᴀᴅ
* ʀᴇsᴛᴀʀᴛ
* ʀᴜɴᴛɪᴍᴇ
* ᴀᴅᴅᴄᴀsᴇ
* ᴅᴇʟᴄᴀsᴇ
* ɢᴇᴛᴄᴀsᴇ
* ʟɪsᴛᴄᴀsᴇ
* ʙʟᴏᴄᴋ
* ᴜɴʙʟᴏᴄᴋ
* ʟɪsᴛʙʟᴏᴄᴋ
* ᴡᴇʟᴄᴏᴍᴇ
* sᴇᴛᴛʜᴜᴍʙɴᴀɪʟ
* sᴇᴛᴘᴘʙᴏᴛᴘᴀɴᴊᴀɴɢ
* ᴄʜᴀɴɢᴇᴍᴇɴᴜ 
* ᴀᴅᴅᴘʀᴇᴍ
* ᴅᴇʟᴘʀᴇᴍ
* ʟɪsᴛᴘʀᴇᴍ
* sᴘᴇᴋʀᴀᴍ
* ʙʀᴏᴀᴅᴄᴀsᴛ 
* ʙʀᴏᴀᴅᴄᴀsᴛᴠ𝟸
* sᴇᴛᴘᴘʙᴏᴛ
* sᴇᴛɴᴀᴍᴀʙᴏᴛ
* sᴇᴛʙɪᴏʙᴏᴛ
* ᴄᴇᴋʙᴏᴛ
* ɢᴄᴀsᴛ
* ɢᴄᴀsᴛᴠ𝟸
* ʟɪsᴛᴘᴄ
* ʙᴄɢᴄ
* ʙᴄɢᴄᴠ𝟸
* ᴘɪɴɢ

*\`𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 ${global.owner}\`*
`
daffmods.sendMessage(m.chat, {text: `${teksmenu}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: fs.readFileSync("./media/thumbnail2.jpg"), title: `© ${namabot} - ${version}`, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
}
break
case 'changemenu':
if (!isOwner) return daffReply(msg.owner)
if (args.length < 1) return daffReply(`Example ${prefix + command} button/non`)
if (q == 'button') {
db.data.settings[botNumber].menuType = 'buttonImage'
daffReply(`Successfully Changed Menu To Button List Image`)
} else if (q == 'non') {
db.data.settings[botNumber].menuType = 'externalImage'
daffReply(`Successfully Changed Auto Typing To External Image`)
}
break
//ubah di settings.js
case 'owner:':{
  daffmods.sendContact(m.chat, global.owner, m)
}
break
//ubah di settings.js
case 'pacar':{
  daffmods.sendContact(m.chat, global.pacar, m)
}
break
//pushkontak fitur
case "pushkontak": {
  if (!isOwner) return daffReply(msg.owner)
  if (!isGroup) return daffReply(msg.group)
  if (!text) return daffReply(example("pesannya"))
  var teks = text
  const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
  daffReply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*`)
  for (let mem of halls) {
  if (mem !== m.sender) {
  contacts.push(mem)
  await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
  await daffmods.sendMessage(mem, {text: teks}, {quoted: qchanel})
  await sleep(global.delaypushkontak)
  }}
  try {
  const uniqueContacts = [...new Set(contacts)]
  const vcardContent = uniqueContacts.map((contact, index) => {
  const vcard = [
  "BEGIN:VCARD",
  "VERSION:3.0",
  `FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
  `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
  "END:VCARD",
  "", ].join("\n")
  return vcard }).join("")
  fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
  } catch (err) {
  m.reply(err.toString())
  } finally {
  if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
  await daffmods.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
  contacts.splice(0, contacts.length)
  await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
  await fs.writeFileSync("./all/database/contacts.vcf", "")
  }}
  break
  case "pushkontak1": {
  if (!isOwner) return daffReply(msg.owner)
  if (!text) return daffReply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
  if (!text.split("|")) return daffReply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
  var [idnya, teks] = text.split("|")
  var groupMetadataa
  try {
  groupMetadataa = await daffmods.groupMetadata(`${idnya}`)
  } catch (e) {
  return daffReply("*ID Grup* tidak valid!")
  }
  const participants = await groupMetadataa.participants
  const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
  daffReply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*`)
  for (let mem of halls) {
  if (mem !== m.sender) {
  contacts.push(mem)
  await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
  await daffmods.sendMessage(mem, {text: teks}, {quoted: qchanel})
  await sleep(global.delaypushkontak)
  }}
  try {
  const uniqueContacts = [...new Set(contacts)]
  const vcardContent = uniqueContacts.map((contact, index) => {
  const vcard = [
  "BEGIN:VCARD",
  "VERSION:3.0",
  `FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
  `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
  "END:VCARD",
  "", ].join("\n")
  return vcard }).join("")
  fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
  } catch (err) {
  m.reply(err.toString())
  } finally {
  if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
  await daffmods.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
  contacts.splice(0, contacts.length)
  await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
  await fs.writeFileSync("./all/database/contacts.vcf", "")
  }}
  break
  case "pushkontak2": {
  if (!isOwner) return daffReply(msg.owner)
  if (!text) return daffReply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
  if (!text.split("|")) return daffReply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
  var idnya = text.split("|")[0]
  var delay = Number(text.split("|")[1])
  var teks = text.split("|")[2]
  if (!idnya.endsWith("@g.us")) return daffReply("Format ID Grup Tidak Valid")
  if (isNaN(delay)) return m.reply("Format Delay Tidak Valid")
  if (!teks) return daffReply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
  var groupMetadataa
  try {
  groupMetadataa = await daffmods.groupMetadata(`${idnya}`)
  } catch (e) {
  return daffReply("*ID Grup* tidak valid!")
  }
  const participants = await groupMetadataa.participants
  const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
  daffReply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*`)
  for (let mem of halls) {
  if (mem !== m.sender) {
  contacts.push(mem)
  await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
  await daffmods.sendMessage(mem, {text: teks}, {quoted: qchanel})
  await sleep(Number(delay))
  }}
  try {
  const uniqueContacts = [...new Set(contacts)]
  const vcardContent = uniqueContacts.map((contact, index) => {
  const vcard = [
  "BEGIN:VCARD",
  "VERSION:3.0",
  `FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
  `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
  "END:VCARD",
  "", ].join("\n")
  return vcard }).join("")
  fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
  } catch (err) {
  m.reply(err.toString())
  } finally {
  if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
  await daffmods.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
  contacts.splice(0, contacts.length)
  await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
  await fs.writeFileSync("./all/database/contacts.vcf", "")
  }}
  break
case 'join': {
if (!isOwner) return daffReply(msg.owner)
 if (!text) return daffReply('Mana Link Grop Nya Tuan ?')
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return daffReply('Link Valid Tuan!!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await daff.groupAcceptInvite(result).then((res) => daffReply(jsonformat(res))).catch((err) => daffReply(jsonformat(err)))
}
break
//jangan dihapus credits ini ya sayang.
case 'tqto':{
  const tqtonya = require('./tqto.js')
  daffReply(tqtonya)
}
break
//ubah aja make biodata kalian, hapus jika tidak digunakan.
case 'about-owner': {
daffmods.sendMessage(m.chat, { text: `HALLO USER!!\n\nCODE NAME: DAXXZMODS\nHOBBY: PROGRAMMING\nRELIGION: ISLAM`}, {quoted:m})
}
break
//fitur cek ping bot whatsapp by daxxzmods.
case 'ping': {
if (!isOwner) return daffReply(msg.owner)
const old = performance.now()
const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB"
const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB"
const serverInfo = `
*🔴 INFORMASI SERVER BOT DaxxzMods*

🖥 CPU : *${os.cpus().length} Core, ${os.cpus()[0].model}*
🕡 Uptime : *${Math.floor(os.uptime() / 86400)} days*
🕡 Runtime : *${runtime(process.uptime())}*
💾 Ram : *${free_ram}/${ram}*
⚡ Speed : *${(performance.now() - old).toFixed(5)} ms*
`
daffmods.sendText(m.chat, serverInfo, m)
}
break
case 'block':
if (!isOwner) return daffReply(msg.owner);
if(isGroup){
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if(users){
await daffmods.updateBlockStatus(users, "block")
daffReply(`Sukses block user`)
} else {
daffReply("Silakan reply pesan atau tag atau input nomer yang mau di block")
}
} else if(!isGroup){
if(q){
var woke = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`
if(woke.startsWith("08")) return daffReply("Awali nomer dengan 62")
if(!woke.startsWith("62")) return daffReply("Silakan reply pesan atau tag atau input nomer yang mau di block")
await daffmods.updateBlockStatus(woke, "block")
} else if(!q){
daffReply("Masukan nomer yang ingin di block")
}
daffReply(`Berhasil Block user ${woke.split("@")[0]}`)
}
break
//=================================================//
case 'unblock':
if (!isOwner) return daffReply(msg.owner);
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if(isGroup){
if(users){
await daffmods.updateBlockStatus(users, "unblock")
await daffReply(`Sukses unblock user`)
} else if(!q){
daffReply("Silakan reply pesan atau tag atau input nomer yang mau di block")
}
} else if(!isGroup){
if(q){
let woke = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`
if(woke.startsWith("08")) return daffReply("Awali nomer dengan 62")
if(!woke.startsWith("62")) return daffReply("Silakan reply pesan atau tag atau input nomer yang mau di block")
await daffmods.updateBlockStatus(woke, "unblock")
daffReply(`Sukses unblock ${woke}`)
} else if(!q){
daffReply("Masukan nomer yang ingin di unblock")
}

}
break
//=================================================//
case 'runtime': case 'infobot': {
if (!isOwner) return daffReply(msg.owner)
let timestamp = speed()
let latensi = speed() - timestamp
let block = await daffmods.fetchBlocklist()
let gcall = Object.values(await daffmods.groupFetchAllParticipating().catch(_=> null))
neww = performance.now()
oldd = performance.now()
ngaceng = fs.readFileSync("./casenyabang.js").toString(),
matches = ngaceng.match(/case '[^']+'(?!.*case '[^']+')/g) || [],
caseCount = matches.length,
caseNames = matches.map(match => match.match(/case '([^']+)'/)[1]);

let totalCases = caseCount,
listCases = caseNames.join('\n${prefix} ');
rafa = `
┌ 𝘽𝙊𝙏 𝙄𝙉𝙁𝙊   
│𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : *${global.namabot2}*
│𝐎𝐰𝐧𝐞𝐫 𝐍𝐚𝐦𝐞 : *${global.owner}* 
│𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝐁𝐨𝐭 : *Private*
│𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : *DaxxzMods🪬*
│𝐌𝐨𝐝𝐞 𝐁𝐨𝐭 : ${daffmods.public ? '*Public*' : '*Self*'}
│𝐓𝐨𝐭𝐚𝐥𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫 : ${reseller == undefined ? '*0* Direseller' : '*' + reseller.length + '* *Reseller'}*
│𝐓𝐨𝐭𝐚𝐥𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫 2 : ${reseller2 == undefined ? '*0* Direseller2' : '*' + reseller2.length + '* *Reseller2'}*
│𝐓𝐨𝐭𝐚𝐥𝐌𝐮𝐫𝐛𝐮𝐠 : ${murbug == undefined ? '*0* Dimurbug' : '*' + murbug.length + '* *Murbug'}*
│𝐓𝐨𝐭𝐚𝐥𝐏𝐫𝐞𝐦 : ${prem == undefined ? '*0* Diprem' : '*' + prem.length + '* *Premium'}*
│𝐓𝐨𝐭𝐚𝐥𝐁𝐥𝐨𝐜𝐤 : ${block == undefined ? '*0* Diblokir' : '*' + block.length + '* *Diblokir'}*
│𝐓𝐨𝐭𝐚𝐥𝐆𝐫𝐮𝐩 : ${gcall == undefined ? '*0* Digcall' : '*' + gcall.length + '* *Grup'}*
│𝐓𝐨𝐭𝐚𝐥𝐅𝐢𝐭𝐮𝐫 : *${totalFitur()} Fitur*
│𝐓𝐨𝐭𝐚𝐥𝐂𝐚𝐬𝐞 : *${totalCases} Case*
│𝐒𝐩𝐞𝐞𝐝 : *${speed()} miliseconds*
│𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : *${runtime(process.uptime())}*
│𝐏𝐫𝐞𝐟𝐢𝐱 :  *No-Prefix*
│𝐑𝐮𝐧𝐧𝐢𝐧𝐠 : *Panel Only*
│𝐋𝐢𝐛𝐫𝐚𝐫𝐲 : *Baileys-Ws*   
│
└─ 𝙐𝙎𝙀𝙍 𝙄𝙉𝙁𝙊 
│𝐍𝐚𝐦𝐞 : *${m.pushName}*
│𝐎𝐰𝐧𝐞𝐫 : *${isOwner ? 'Owner✅' : 'Bukan Owner❌'}*
│𝐏𝐫𝐞𝐦𝐢𝐮𝐦 : *${isPrem ? 'Sudah Premium✅' : `Belom Premium❌`}*
│𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫 : *${isReseller ? 'Sudah Reseller✅' : `Belom Reseller❌`}*
│𝐑𝐞𝐬𝐞𝐥𝐥𝐞𝐫 2 : *${isReseller2 ? 'Sudah Reseller2✅' : `Belom Reseller2❌`}*
│
└─ 𝙏𝙄𝙈𝙀 𝙄𝙉𝙁𝙊 
│𝐓𝐢𝐦𝐞 : *${time}*
│𝐇𝐚𝐫𝐢𝐈𝐧𝐢 : *${salam}*
└─────────────┈ ✈`
daffmods.sendOrder(m.chat, rafa, fs.readFileSync('./media/thumbnail.jpg'), "99999999", 10000000, qchanel)
}
break
case "yts": {
if (!isOwner && !isPrem) return daffReply('Maaf Perintah Ini Khusus Premium Kami.')
if (!text) return m.reply(example("Dj Tiktok"))
await m.reply(msg.wait)
await yts(text).then(async (data) => {
if (data.all.length == 0) return m.reply(mess.error)
let teks = '\n*🔎Hasil Pencarian YOUTUBE*\n\n'
for (let i of data.all) {
teks += `*◦ Judul :* ${i.title}
*◦ Channel :* ${i.author?.name || "unknown"}
*◦ Durasi :* ${i?.timestamp || "unknown"}
*◦ Link Url :* ${i.url}\n\n`
}
m.reply(teks)
}).catch(err => m.reply(err.toString()))
}
break
case "ytmp3": case "ytdl": {
if (!isOwner && !isPrem) return daffReply('Maaf Perintah Ini Khusus Premium Kami.')
if (!text) return m.reply(example('linknya'))
if (!text.includes("https")) return m.reply("Link Tautan Tidak Valid!")
if (!text.includes("youtu")) return m.reply("Link Tautan Tidak Valid!")
m.reply(msg.wait)
var judul = `./all/tmp/${getRandom(".mp3")}`
const videoURL = text
const options = {
  quality: 'highestaudio',
  filter: 'audioonly'
}
ytdl(videoURL, options)
  .pipe(fs.createWriteStream(judul))
  .on('finish', async function () {
var ai = await yts(text)
var vid = ai.videos[0]
try {
let { title, thumbnail: thumb, timestamp, author, url } = vid
await daff.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg', contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: thumb, title: title, body: `Duration : ${timestamp} | Author : ${author.name}`, sourceUrl: null,  renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await fs.unlinkSync(judul)
} catch (e) {
await daff.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg'}, {quoted: m})
await fs.unlinkSync(judul)
}
}).on('error', (err) => {
return m.reply(err.toString())
})}
break
case "setthumb": case "setthumbnail": {

if (!isOwner) return daffReply(msg.owner)
if (!/image/g.test(mime)) return m.reply("Kirim/Balas Foto")
await daffmods.downloadAndSaveMediaMessage(qmsg, "./media/thumbnail.jpg", false)
m.reply("Berhasil Mengganti Foto Thumbnail Menu ✅")
}
break
case "setppbot": case "setpp": {

if (!isOwner) return daffReply(msg.owner)
if (/image/g.test(mime)) {
let media = await daffmods.downloadAndSaveMediaMessage(qmsg)
await daffmods.updateProfilePicture(botNumber, {url: media})
await fs.unlinkSync(media)
m.reply("Berhasil Mengganti Foto Profile Bot ✅")
} else return m.reply(example('dengan mengirim foto'))}
break
case "setppbotpanjang": case "setpppanjang": {

if (!isOwner) return daffReply(msg.owner)
if (/image/g.test(mime)) {
var medis = await daffmods.downloadAndSaveMediaMessage(qmsg, 'ppbot.jpeg', false)
var { img } = await generateProfilePicture(medis)
await daffmods.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
m.reply("Berhasil Mengganti Foto Profil Bot ✅")
} else return m.reply(example('dengan mengirim foto'))
}
break
case "ytplay": case "play": {
if (!isOwner && !isPrem) return daffReply('Maaf Perintah Ini Khusus Premium Kami.')
if (!text) return m.reply(example('Dj tiktok'))
m.reply(msg.wait)
const { pipeline } = require('stream')
const { promisify } = require('util')
const streamPipeline = promisify(pipeline)
try {
let search = await yts(text)
let vid = search.videos[0]
let { title, thumbnail: thumb, timestamp, author, url } = vid
const audioStream = ytdl(url, {
filter: 'audioonly',
quality: 'highestaudio'})
let acak = await getRandom(".mp3")
let temp = "./all/tmp/" + acak
const writableStream = fs.createWriteStream(temp)
await streamPipeline(audioStream, writableStream)
await daffmods.sendMessage(m.chat, {audio: fs.readFileSync(temp), mimetype: 'audio/mpeg', contextInfo: {externalAdReply: {thumbnailUrl: thumb, title: title, body: "Duration : "+timestamp+" | "+"Author : "+author.name, sourceUrl: url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await fs.unlinkSync(temp)
} catch (e) {
return m.reply(e.toString())
}
}
break
case "qc": {
if (!isOwner && !isPrem) return daffReply('Maaf Perintah Ini Khusus Premium Kami.')
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000"]
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
m.reply(msg.wait)
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": reswarna,
  "width": 512,
  "height": 768,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = makeid+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await daffmods.sendStimg(m.chat, tempnya, m, {packname: namabot})
fs.unlinkSync(`./${tempnya}`)
})
})
}
break
case "sticker": case "stiker": case "sgif": case "s": {

if (!/image|video/.test(mime)) return m.reply(example("dengan mengirim foto/vidio"))
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
m.reply(msg.wait)
var media = await daffmods.downloadAndSaveMediaMessage(qmsg)
await daffmods.sendStimg(m.chat, media, m, {packname: global.packname})
await fs.unlinkSync(media)
}
break
case "tourl": {

if (!/image/.test(mime)) return m.reply(example("dengan mengirim foto"))
await m.reply(msg.wait)
var fotonya = await daffmods.downloadAndSaveMediaMessage(qmsg)
var urlimage = await telegraPh(fotonya)
await m.reply(`Link Tautan :\n${urlimage}`)
await fs.unlinkSync(fotonya)
}
break
case "public": {

if (!isOwner) return daffReply(msg.owner)
daffmods.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break
case "self": {

if (!isOwner) return daffReply(msg.owner)
daffmods.public = false
m.reply("Berhasil mengganti mode bot menjadi *Self*")
}
break
case "get": {

if (!isOwner) return daffReply(msg.owner)
if (!text) return m.reply("linknya")
try {
var check = await fetchJson(text)
m.reply(JSON.stringify(check, null, 2))
} catch (e) {
return m.reply(e.toString())
}}
break
case "tiktok": case "tt":  case "toktok": {
if (!isOwner && !isPrem) return daffReply('Maaf Perintah Ini Khusus Premium Kami.')
if (!text) return m.reply(example('linknya'))
if (!/tiktok.com/.test(text)) return m.reply("Link Tautan Tidak Valid!")
m.reply(msg.wait)
 let anuan = text
await api.tiktok(anuan).then(async (res) => {
var cap = `*Tiktok Downloader Done ✅*`
if (res.result.duration == 0) {
for (let a of res.result.images) {
daffmods.sendMessage(m.chat, {image: {url: `${a}`}, caption: cap}, {quoted: m})
}
} else {
await daffmods.sendMessage(m.chat, {video: {url: res.result.play}, mimetype: "video/mp4", caption: cap}, {quoted: m})
}
}).catch(e => m.reply(e.toString))
}
break
case "ownerbot": {

daffmods.sendContact(m.chat, [owner], "Developer Bot WhatsApp", null, {contextInfo: {
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true, 
thumbnail: await fs.readFileSync("./media/owner.jpg"), 
title: `© Copyright ${global.namabot}`, 
renderLargerThumbnail: true, 
sourceUrl: global.linkyt, 
mediaType: 1
}}})
}
break
case "antilink": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner && !isAdmin) return daffReply(msg.admin)
if (!args[0]) return m.reply(example("on/off\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini"))
if (/on/.test(args[0].toLowerCase())) {
if (antilink.includes(m.chat)) return m.reply("*Antilink* Di Grup Ini Sudah Aktif!\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
if (antilink2.includes(m.chat)) {
let posi = antilink2.indexOf(m.chat)
antilink2.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
}
antilink.push(m.chat)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
m.reply("Berhasil Menyalakan *Antilink* Di Grup Ini ✅\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else if (/off/.test(args[0].toLowerCase())) {
if (!antilink.includes(m.chat)) return m.reply("*Antilink* Di Grup Ini Belum Aktif!\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
let posi = antilink.indexOf(m.chat)
antilink.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
m.reply("Berhasil Mematikan *Antilink* Di Grup Ini ❌\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else {
return m.reply(example("on/off"))
}}
break
case "antilinkV2": case "antilinkv2": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner && !isAdmin) return daffReply(msg.owner)
if (!args[0]) return m.reply(example("on/off\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini"))
if (/on/.test(args[0].toLowerCase())) {
if (antilink2.includes(m.chat)) return m.reply("*AntilinkV2* Di Grup Ini Sudah Aktif!\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
if (antilink.includes(m.chat)) {
let posi = antilink.indexOf(m.chat)
antilink.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
}
antilink2.push(m.chat)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
m.reply("Berhasil Menyalakan *AntilinkV2* Di Grup Ini ✅\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else if (/off/.test(args[0].toLowerCase())) {
if (!antilink2.includes(m.chat)) return m.reply("*AntilinkV2* Di Grup Ini Belum Aktif!\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
let posi = antilink2.indexOf(m.chat)
antilink2.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
m.reply("Berhasil Mematikan *Antilink* Di Grup Ini ❌\n\nKetik *.statusgc* Untuk Melihat Status Setting Grup Inii")
} else {
return m.reply(example("on/off"))
}}
break
case "welcome": {

if (!isOwner) return daffReply(msg.owner)
if (!text) return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
if (text.toLowerCase() == "on") {
if (welcome) return m.reply("*Welcome* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
welcome = true
m.reply("Berhasil Menyalakan *Welcome ✅*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!welcome) return m.reply("*Welcome* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
welcome = false
m.reply("Berhasil Mematikan *Welcome ❌*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break
case "autoread": {

if (!isOwner) return daffReply(msg.owner)
if (!text) return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
if (text.toLowerCase() == "on") {
if (autoread) return m.reply("*Autoread* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
autoread = true
m.reply("Berhasil Menyalakan *Autoread ✅*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!autoread) return m.reply("*Autoread* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
autoread = false
m.reply("Berhasil Mematikan *Autoread ❌*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break
case "anticall": {

if (!isOwner) return daffReply(msg.owner)
if (!text) return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
if (text.toLowerCase() == "on") {
if (anticall) return m.reply("*Anticall* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
anticall = true
m.reply("Berhasil Menyalakan *Anticall ✅*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!anticall) return m.reply("*Anticall* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
anticall = false
m.reply("Berhasil Mematikan *Anticall ❌*\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break
case "setting": case "settingbot": case "option": case "statusbot": {

if (!isOwner) return daffReply(msg.owner)
var teks = `
*List Status Bot Settings :*

* Autoread : ${global.autoread ? "*Aktif ✅*" : "*Tidak Aktif ❌*"}
* Anticall : ${global.anticall ? "*Aktif ✅*" : "*Tidak Aktif ❌*"}
* Welcome : ${global.welcome ? "*Aktif ✅*" : "*Tidak Aktif ❌*"}

*Contoh Penggunaan :*
Ketik *.autoread* on/off`
m.reply(teks)
}
break
case "statusgc": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
var anti1 = "Aktif ✅"
var anti2 = "Aktif ✅"
if (!antilink2.includes(m.chat)) anti2 = "Tidak Aktif ❌"
if (!antilink.includes(m.chat)) anti1 = "Tidak Aktif ❌"
var teks = `
*List Status Grup Settings :*

* Antilink : *${anti1}*
* AntilinkV2 : *${anti2}*

*Contoh Penggunaan :*
Ketik *.antilink* on/off
`
daffmods.senText(m.chat, teks, qchanel)
}
break
case "setppgc": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (/image/g.test(mime)) {
let media = await daffmods.downloadAndSaveMediaMessage(qmsg)
await daffmods.updateProfilePicture(m.chat, {url: media})
await fs.unlinkSync(media)
m.reply("Berhasil Mengganti *Profil* Grup")
} else return m.reply(example('dengan mengirim foto'))}
break
case "setdesc": case "setdesk": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (!text) return m.reply(example('teksnya'))
await daffmods.groupUpdateDescription(m.chat, text)
m.reply(`Berhasil Mengganti *Deskripsi* Grup`)
}
break
case "open": {

if (!isGroup) return daffReply(msg.group)
if (!isBotAdmin) return daffReply(msg.adminbot)
if (!isOwner) return daffReply(msg.owner)
await daffmods.groupSettingUpdate(m.chat, 'not_announcement')
m.reply("Berhasil Mengganti Setelan Grup Menjadi Anggota Dapat Mengirim Pesan")
}
break
case "close": {

if (!isGroup) return daffReply(msg.group)
if (!isBotAdmin) return daffReply(msg.adminbot)
if (!isOwner) return daffReply(msg.owner)
await daffmods.groupSettingUpdate(m.chat, 'announcement')
m.reply("Berhasil Mengganti Setelan Grup Menjadi Hanya Admin Yang Dapat Mengirim Pesan")
}
break
case "del": case "delete": {

if (isGroup) {
if (!isOwner) return daffReply(msg.owner)
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
if (m.quoted.sender == botNumber) {
daff.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!isBotAdmin) return daffReply(msg.adminbot)
daffmods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isOwner) return daffReply(msg.owner)
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
daffmods.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}}
break
case "demote": case "demote": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (!isBotAdmin) return daffReply(msg.adminbot)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await daffmods.groupParticipantsUpdate(m.chat, [target], 'demote').then((res) => m.reply(`Berhasil Memberhentikan ${target.split("@")[0]} Sebagai Admin Grup Ini`)).catch((err) => m.reply(err.toString()))
} else return m.reply(example('62838XXX'))}
break
case "promote": case "promot": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (!isBotAdmin) return daffReply(msg.adminbot)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await daffmods.groupParticipantsUpdate(m.chat, [target], 'promote').then((res) => m.reply(`Berhasil Menjadikan ${target.split("@")[0]} Sebagai Admin Grup Ini`)).catch((err) => m.reply(err.toString()))
} else return m.reply(example('62838XXX'))}
break
case "add": case "addmember": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (!args[0]) return m.reply(example("62838XXX"))
var teks = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var cek = await daffmods.onWhatsApp(`${teks.split("@")[0]}`)
if (cek.length < 1) return m.reply("Nomor Tersebut Tidak Terdaftar Di WhatsApp")
if (!isBotAdmin || !groupMetadata.memberAddMode) return m.reply("Gagal Menambahkan Member, Karna Admin Tidak Mengizinkam Peserta Dapat Add Member")
var a = await daffmods.groupParticipantsUpdate(m.chat, [teks], 'add')
if (a[0].status == 200) return m.reply(`Berhasil Menambahkan ${teks.split("@")[0]} Kedalam Grup Ini`)
if (a[0].status == 408) return m.reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
if (a[0].status == 409) return m.reply(`Dia Sudah Ada Di Dalam Grup Ini!`)
if (a[0].status == 403) return m.reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
}
break
case "kik": case "kick": {

if (!isGroup) return daffReply(msg.group)
if (!isBotAdmin) return daffReply(msg.adminbot)
if (!isOwner) return daffReply(msg.owner)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await daffmods.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => daffmods.sendMessage(m.chat, {text: `Berhasil Mengeluarkan @${users.split("@")[0]} Dari Grup Ini`, mentions: [`${users}`]}, {quoted: m})).catch((err) => m.reply(err.toString()))
} else return m.reply(example('nomornya/@tag'))}
break
case "hidetag": case "z": case "h": {

if (!isGroup) return daffReply(msg.group)
if (!isOwner) return daffReply(msg.owner)
if (!m.quoted && !text) return m.reply(example("teksnya/replyteks"))
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
daffmods.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "listgc": case "cekidgc": case"listgrup": {

let gcall = Object.values(await daffmods.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
daffmods.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `[ ${gcall.length} Group Chat ] `, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
}
break
case "joingc": case "join": {

if (!isOwner) return daffReply(msg.owner)
if (!text && !m.quoted) return m.reply(example('linknya'))
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return m.reply("Link Tautan Tidak Valid!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await daffmods.groupAcceptInvite(result).then(respon => m.reply("Berhasil Bergabung Ke Dalam Grup ✅")).catch(error => m.reply(error.toString()))
}
break
case "leave": case "leavegc": {

if (!isOwner) return daffReply(msg.owner)
if (!isGroup) return daffReply(msg.group)
await m.reply("Otw Out Abangkuhh🔥")
await sleep(3000)
await daffmods.groupLeave(m.chat)
}
break
case "danamasuk": {
if (!isOwner) return daffReply(msg.owner)
rafa = `*DONE DANA MASUK✅*

Ram : 
Reqname :
▰▰▰▰▰▰▰▰
*Garansi 7 Day*
*Create ${tanggal2}*
*Hari Ini ${hariini}*`
daffmods.sendOrder(m.chat, rafa, fs.readFileSync('./media/thumbnail.jpg'), "99999999", 10000000, qchanel)
}
break
case "done": {
if (!isOwner) return daffReply(msg.owner)
let t = text.split(',');
if (t.length < 2) return daffReply(`*Format salah!*
Penggunaan:
${prefix + command} barang,nominal,sistem, paymentt`);
let barang = t[0];
let nominal = t[1];
let sistem = t[2];
let paymentt = t[3];
var teks = `
_*Alhamdulillah Next Order Cik✅*_

 _• *Barang:* ${barang}_
 _• *Nominal:* Rp${nominal}_
 _• *Payment:* ${paymentt}_
 _• *Sistem:* ${sistem}_
 _• *Nama store:* ${namabot}_

*List Market DaxxzMods*

> _• Panel 1Gb-Unli_
> _• MURLOG,MURBUG,MURNOKOS,MURPUSH 5K_
> _• RESELLER PANEL 1 BULAN 5K_
> _• RESELLER PANEL PERMANEN 7K_
> _• ADMIN PANEL PERMANEN 10K_
> _• PT PANEL PERMANEN 20K_
> _• DLL TANYA AJA_
======================
☎️Contact Admin☎️
> 📞Nope Admin : Wa.me/6285283112644

*Transaksi Done By ${namaowner} ✅*`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Youtube\",\"url\":\"${global.linkyt}\",\"merchant_url\":\"https://t.me/DaffError505\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Telegram\",\"url\":\"${global.linktele}\",\"merchant_url\":\"https://t.me/DaffError505\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testi Diwhatsapp\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://t.me/DaffError505\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testi Ditelegram\",\"url\":\"https://t.me/DaffError505\",\"merchant_url\":\"https://t.me/DaffError505\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtext}) 
await daffmods.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case 'pay': {
if (!isOwner) return daffReply(msg.owner)
paymentnya = `DANA: 081295532922 A/N: IY** SU******TI\n\nSilakan ss hasil bukti transfer`
daffReply(paymentnya)
}
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return daffmods.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return daffmods.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
daffmods.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
daffmods.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return daffmods.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return daffmods.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
//daffmods.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})