require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285283112644" //ganti make nomor lo
global.pacarOwner = "628192141942" //ganti make nomor pacar/owner2, jangan dihapus nanti malah error
global.namaowner = "DaxxzMods" //ganti make code name lo atau nama asli lo njuga boleh
global.namaPacar = "firyall" //ganti make nama cewe lo

//======== Setting Bot & Link ========//
global.namabot = "KilzzBotz V16" //ganti make nama bot lo jing
global.namabot2 = "KilzzBotz V16" //samain aja kaya namabot yang atas biar ga bingung
global.ownerbot = "6285283112644" //ganti make nomor lo asu
global.foother = "© Copyright By DaxxzMods" //copyright untuk ditampilkan di bagian bagian penting
global.idsaluran = "_" //kasih tanda - bila tidak ada id saluran
global.linkgc = 'https://whatsapp.com/HBtcCUIjRagLAULKB3BvC2' //ganti make linkgc lo
global.linksaluran = "-" //kasih tanda - bila tidak ada link saluranmu
global.apitokendo = '-' // API AKUN DIGITAL OCEAN ANDA, - jika gapunya
global.linkyt = 'https://www.youtube.com/@DaffBotz' //isi make link yt lo
global.linktele = "https://t.me/DaffError505" //ganti make link telegram lo
global.packname = "Sticker By"
global.author = "KilzzBotz V16"
global.footer2 = '© Copyright By DaxxzMods'
global.foter1 = 'Script type Case'
global.foter2 = '𝘚𝘤𝘳𝘪𝘱𝘵 𝘴𝘪𝘮𝘱𝘭𝘦 by DaxxzMods'

//========== Setting Event ==========//
global.welcome = false //ganti true jika ingin mengaktifkan
global.autoread = false //ganti true jika ingin mengaktifkan
global.anticall = true //ganti false jika ingin mengaktifkan
global.owneroff = false //ganti true jika ingin mengaktifkan

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 2000 //ubah delay menjadi 4000 jika mau meminimalisir banned dalam pushkontak
global.delayjpm = 2000 //ubah delay menjadi 400 jika mau meminimalisir banned dalam jpm

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "081295532922" //nope dana lo
global.gopay = "-" //nope gopay lo
global.ovo = "-" //nope ovo lo
                             
//========= Setting Message =========//
global.msg = {
"error": "Error terjadi kesalahan",
"done": "Done Bang ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!*", 
"private": "*Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!*", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin*", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*Only For DaxxzMods*"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})